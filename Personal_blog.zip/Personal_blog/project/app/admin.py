from django.contrib import admin
from .models import Contact

# Register your models here.
class contactadmin(admin.ModelAdmin):
    list_display=['fristname','lastname','email','massage']

admin.site.register(Contact,contactadmin)