from django.urls import path
from app import views


urlpatterns = [
    path('', views.home ,name = "home"),
    path("achivements", views.achivements , name = "achivements"),
    path("contact/" , views.contact , name = "contact"),
    path("about/" , views.about , name = "about"),
    path("projects" , views.projects , name = "projects"),
    
]
